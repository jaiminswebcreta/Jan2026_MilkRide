"use strict";

// Class definition
var KTModalNewTarget = function () {
    var submitButton;
    var cancelButton;
    var validator;
    var form;
    var modal;
    var modalEl;

    // Init form inputs
    var initForm = function () {
        // Tags. For more info, please visit the official plugin site: https://yaireo.github.io/tagify/
        var tags = new Tagify(form.querySelector('[name="tags"]'), {
            whitelist: ["Important", "Urgent", "High", "Medium", "Low"],
            maxTags: 5,
            dropdown: {
                maxItems: 10, // <- mixumum allowed rendered suggestions
                enabled: 0, // <- show suggestions on focus
                closeOnSelect: false // <- do not hide the suggestions dropdown once an item has been selected
            }
        });
        tags.on("change", function () {
            // Revalidate the field when an option is chosen
            validator.revalidateField('tags');
        });

        // Due date. For more info, please visit the official plugin site: https://flatpickr.js.org/
        var dueDate = $(form.querySelector('[name="due_date"]'));
        dueDate.flatpickr({
            enableTime: true,
            dateFormat: "d, M Y, H:i",
        });

        // Team assign. For more info, plase visit the official plugin site: https://select2.org/
        $(form.querySelector('[name="team_assign"]')).on('change', function () {
            // Revalidate the field when an option is chosen
            validator.revalidateField('team_assign');
        });
    }

    // Handle form validation and submittion
    var handleForm = function () {
        // Stepper custom navigation

        // Init form validation rules. For more info check the FormValidation plugin's official documentation:https://formvalidation.io/
        validator = FormValidation.formValidation(
            form, {
                fields: {
                    reason_id: {
                        validators: {
                            notEmpty: {
                                message: 'Reason is required'
                            }
                        }
                    },

                },
                plugins: {
                    trigger: new FormValidation.plugins.Trigger(),
                    bootstrap: new FormValidation.plugins.Bootstrap5({
                        rowSelector: '.fv-row',
                        eleInvalidClass: '',
                        eleValidClass: ''
                    })
                }
            }
        );

        // Action buttons
        submitButton.addEventListener('click', function (e) {
            e.preventDefault();

            // Validate form before submit
            if (validator) {
                validator.validate().then(function (status) {
                    console.log('validated!');

                    if (status == 'Valid') {
                        submitButton.setAttribute('data-kt-indicator', 'on');

                        // Disable button to avoid multiple click
                        submitButton.disabled = true;

                        setTimeout(function () {
                            submitButton.removeAttribute('data-kt-indicator');

                            // Enable button
                            submitButton.disabled = false;

                            // var deleteButton = document.querySelector('button[onclick="confirmDelete(' + id + ', \'' + itemName + '\')"]');
                            // var deleteForm = deleteButton.closest('.menu-item');
                            // var formElement = deleteForm.querySelector('form');
                            var subscription_id = 'Order subscription';

                            var formAction = $('#kt_modal_new_target_form').attr('action');

                            Swal.fire({
                                text: getResourceMessage('confirm_delete','order subscription'),
                                icon: "warning",
                                showCancelButton: true,
                                confirmButtonText: "Yes, Delete",
                                cancelButtonText: "No, Cancel",
                                customClass: {
                                    confirmButton: "btn btn-primary",
                                    cancelButton: "btn btn-danger",
                                },
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    // AJAX form submission
                                    var formData = new FormData($('#kt_modal_new_target_form')[0]);
                                    fetch(formAction, {
                                        method: 'POST',
                                        body: formData
                                    }).then(response => {
                                        if (response.ok) {
                                            Swal.fire({
                                                title: getResourceMessage('delete','Order subscription'),
                                                icon: "success",
                                                buttonsStyling: false,
                                                confirmButtonText: "Okay, got it!",
                                                customClass: {
                                                    confirmButton: "btn btn-dark"
                                                }
                                            }).then((result) => {
                                                location.reload();
                                            });
                                        } else {
                                            throw new Error('Something went wrong');
                                        }
                                    }).then(() => {
                                        // Remove or hide the deleted item from the DOM
                                        deleteForm.style.display = 'none'; // or use deleteForm.remove();
                                    }).catch(error => {
                                        // Handle any errors here
                                        console.error('Error:', error);
                                    });
                                } else {
                                    // Show cancellation message
                                    Swal.fire({
                                        title: getResourceMessage('regret',''),
                                        icon: "error",
                                        confirmButtonText: "Got it",
                                        customClass: {
                                            confirmButton: "btn btn-dark"
                                        }
                                    });
                                }
                            });
                        }, 2000);
                    } else {
                        // Show error message.
                        Swal.fire({
                            text: "Sorry, looks like there are some errors detected, please try again.",
                            icon: "error",
                            buttonsStyling: false,
                            confirmButtonText: "Ok, got it!",
                            customClass: {
                                confirmButton: "btn btn-primary"
                            }
                        });
                    }
                });
            }
        });

        cancelButton.addEventListener('click', function (e) {
            e.preventDefault();

            Swal.fire({
                text: "Are you sure you would like to cancel?",
                icon: "warning",
                showCancelButton: true,
                buttonsStyling: false,
                confirmButtonText: "Yes, cancel it!",
                cancelButtonText: "No, return",
                customClass: {
                    confirmButton: "btn btn-primary",
                    cancelButton: "btn btn-active-light"
                }
            }).then(function (result) {
                if (result.value) {
                    form.reset(); // Reset form
                    modal.hide(); // Hide modal
                } else if (result.dismiss === 'cancel') {
                    Swal.fire({
                        text: "Your form has not been cancelled!.",
                        icon: "error",
                        buttonsStyling: false,
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn btn-primary",
                        }
                    });
                }
            });
        });
    }

    return {
        // Public functions
        init: function () {
            // Elements
            modalEl = document.querySelector('#kt_modal_new_target');

            if (!modalEl) {
                return;
            }

            $('#kt_modal_new_target').on('show.bs.modal', function (event) {
                // Get the button that triggered the modal
                var button = $(event.relatedTarget);

                // Extract subscription id from data-subscription-id attribute
                var subscription_id = button.data('subscription-id');

                // Update the hidden input value in the form
                $('#subscriptionIdInput').val(subscription_id);

                // Get the form action and replace :subscriptionId with the actual ID
                var formAction = $('#kt_modal_new_target_form').attr('action');
                formAction = formAction.replace(':subscription_id', subscription_id);

                // Update the form action
                $('#kt_modal_new_target_form').attr('action', formAction);

            });

            modal = new bootstrap.Modal(modalEl);

            form = document.querySelector('#kt_modal_new_target_form');
            submitButton = document.getElementById('kt_modal_new_target_submit');
            cancelButton = document.getElementById('kt_modal_new_target_cancel');

            initForm();
            handleForm();
        }
    };
}();

// Class definition
var KTModalNewOrderTarget = function () {
    var submitButton;
    var cancelButton;
    var validator;
    var form;
    var modal;
    var modalEl;

    // Init form inputs
    var initForm = function () {
        // Tags. For more info, please visit the official plugin site: https://yaireo.github.io/tagify/
        var tags = new Tagify(form.querySelector('[name="tags"]'), {
            whitelist: ["Important", "Urgent", "High", "Medium", "Low"],
            maxTags: 5,
            dropdown: {
                maxItems: 10, // <- mixumum allowed rendered suggestions
                enabled: 0, // <- show suggestions on focus
                closeOnSelect: false // <- do not hide the suggestions dropdown once an item has been selected
            }
        });
        tags.on("change", function () {
            // Revalidate the field when an option is chosen
            validator.revalidateField('tags');
        });

        // Due date. For more info, please visit the official plugin site: https://flatpickr.js.org/
        var dueDate = $(form.querySelector('[name="due_date"]'));
        dueDate.flatpickr({
            enableTime: true,
            dateFormat: "d, M Y, H:i",
        });

        // Team assign. For more info, plase visit the official plugin site: https://select2.org/
        $(form.querySelector('[name="team_assign"]')).on('change', function () {
            // Revalidate the field when an option is chosen
            validator.revalidateField('team_assign');
        });
    }

    // Handle form validation and submittion
    var handleForm = function () {
        // Stepper custom navigation

        // Init form validation rules. For more info check the FormValidation plugin's official documentation:https://formvalidation.io/
        validator = FormValidation.formValidation(
            form, {
                fields: {
                    reason_id: {
                        validators: {
                            notEmpty: {
                                message: 'Reason is required'
                            }
                        }
                    },

                },
                plugins: {
                    trigger: new FormValidation.plugins.Trigger(),
                    bootstrap: new FormValidation.plugins.Bootstrap5({
                        rowSelector: '.fv-row',
                        eleInvalidClass: '',
                        eleValidClass: ''
                    })
                }
            }
        );

        // Action buttons
        submitButton.addEventListener('click', function (e) {
            e.preventDefault();

            // Validate form before submit
            if (validator) {
                validator.validate().then(function (status) {
                    console.log('validated!');

                    if (status == 'Valid') {
                        submitButton.setAttribute('data-kt-indicator', 'on');

                        // Disable button to avoid multiple click
                        submitButton.disabled = true;

                        setTimeout(function () {
                            submitButton.removeAttribute('data-kt-indicator');

                            // Enable button
                            submitButton.disabled = false;

                            // var deleteButton = document.querySelector('button[onclick="confirmDelete(' + id + ', \'' + itemName + '\')"]');
                            // var deleteForm = deleteButton.closest('.menu-item');
                            // var formElement = deleteForm.querySelector('form');
                            var order_id = $('#orderIdInput').val();

                            var formAction = $('#kt_modal_new_order_target_form').attr('action');

                            Swal.fire({
                                text: getResourceMessage('confirm_delete','order'),
                                icon: "warning",
                                showCancelButton: true,
                                confirmButtonText: "Yes, Delete",
                                cancelButtonText: "No, Cancel",
                                customClass: {
                                    confirmButton: "btn btn-primary",
                                    cancelButton: "btn btn-danger",
                                },
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    // AJAX form submission
                                    var formData = new FormData($('#kt_modal_new_order_target_form')[0]);
                                    fetch(formAction, {
                                        method: 'POST',
                                        body: formData
                                    }).then(response => {
                                        if (response.ok) {
                                            Swal.fire({
                                                title: getResourceMessage('delete','Order'),
                                                icon: "success",
                                                buttonsStyling: false,
                                                confirmButtonText: "Okay, got it!",
                                                customClass: {
                                                    confirmButton: "btn btn-dark"
                                                }
                                            }).then((result) => {
                                                location.reload();
                                            });
                                        } else {
                                            throw new Error('Something went wrong');
                                        }
                                    }).then(() => {
                                        // Remove or hide the deleted item from the DOM
                                        deleteForm.style.display = 'none'; // or use deleteForm.remove();
                                    }).catch(error => {
                                        // Handle any errors here
                                        console.error('Error:', error);
                                    });
                                } else {
                                    // Show cancellation message
                                    Swal.fire({
                                        title: getResourceMessage('regret',''),
                                        icon: "error",
                                        confirmButtonText: "Got it",
                                        customClass: {
                                            confirmButton: "btn btn-dark"
                                        }
                                    });
                                }
                            });
                        }, 2000);
                    } else {
                        // Show error message.
                        Swal.fire({
                            text: "Sorry, looks like there are some errors detected, please try again.",
                            icon: "error",
                            buttonsStyling: false,
                            confirmButtonText: "Ok, got it!",
                            customClass: {
                                confirmButton: "btn btn-primary"
                            }
                        });
                    }
                });
            }
        });

        cancelButton.addEventListener('click', function (e) {
            e.preventDefault();

            Swal.fire({
                text: "Are you sure you would like to cancel?",
                icon: "warning",
                showCancelButton: true,
                buttonsStyling: false,
                confirmButtonText: "Yes, cancel it!",
                cancelButtonText: "No, return",
                customClass: {
                    confirmButton: "btn btn-primary",
                    cancelButton: "btn btn-active-light"
                }
            }).then(function (result) {
                if (result.value) {
                    form.reset(); // Reset form
                    modal.hide(); // Hide modal
                } else if (result.dismiss === 'cancel') {
                    Swal.fire({
                        text: "Your form has not been cancelled!.",
                        icon: "error",
                        buttonsStyling: false,
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn btn-primary",
                        }
                    });
                }
            });
        });
    }

    return {
        // Public functions
        init: function () {
            // Elements
            modalEl = document.querySelector('#kt_modal_new_order_target');

            if (!modalEl) {
                return;
            }

            $('#kt_modal_new_order_target').on('show.bs.modal', function (event) {
                // Get the button that triggered the modal
                var button = $(event.relatedTarget);

                // Extract order id from data-order-id attribute
                var order_id = button.data('order-id');

                // Update the hidden input value in the form
                $('#orderIdInput').val(order_id);

                // Get the form action and replace :orderId with the actual ID
                var formAction = $('#kt_modal_new_order_target_form').attr('action');
                formAction = formAction.replace(':order_id', order_id);

                // Update the form action
                $('#kt_modal_new_order_target_form').attr('action', formAction);

            });

            modal = new bootstrap.Modal(modalEl);

            form = document.querySelector('#kt_modal_new_order_target_form');
            submitButton = document.getElementById('kt_modal_new_order_target_submit');
            cancelButton = document.getElementById('kt_modal_new_order_target_cancel');

            initForm();
            handleForm();
        }
    };
}();

// On document ready
KTUtil.onDOMContentLoaded(function () {
    KTModalNewTarget.init();
    KTModalNewOrderTarget.init();
});


function getResourceMessage(action, resource) {
    const messages = {
        'create': '[Resource] created successfully.',
        'read': '[Resource] retrieved successfully.',
        'update': '[Resource] updated successfully.',
        'delete': '[Resource] deleted successfully.',
        'cancel': '[Resource] cancelled successfully.',
        'disable': '[Resource] disabled successfully.',
        'transfer': '[Resource] transferred successfully.',
        'delivered': '[Resource] Delivered successfully.',
        'refund': '[Resource] status updated successfully.',
        'cancelled_n_refunded': '[Resource] was successfully cancelled and refunded.',
        'confirm_delete': 'Are you sure you want to delete [Resource]?',
        'regret': 'We regret to inform you that cancellation was unsuccessful.',
        'regret_delete': 'We regret to inform you that deletion was unsuccessful.',
        'status_update': 'The status of your [Resource] has been updated.',
        'shifted': 'Your order subscription has been smoothly shifted.'
    };

    if (messages.hasOwnProperty(action)) {
        return messages[action].replace('[Resource]', resource).replace('[resource]', resource.toLowerCase());
    }

    return 'Invalid action specified.';
}
