"use strict";

var KTSubscriptionsProducts = function () {
    // Shared variables
    var table;
    var datatable;
    var modalEl;
    var modal;

    var initDatatable = function () {
        // Init datatable --- more info on datatables: https://datatables.net/manual/
        datatable = $(table).DataTable({
            "info": false,
            'order': [],
            'ordering': false,
            'paging': false,
            "lengthChange": false,
        });

        // Hide the table header using CSS
        $(table).find('thead').css('display', 'none');
    }

    var saveButton = document.getElementById('saveButton');

    // Function to enable or disable the Save button based on tbody content
    function updateSaveButtonStatus() {
        var tbody = document.querySelector('#kt_subscription_products_table tbody');
        var tbodyContent = tbody.innerHTML.trim();

        if (tbodyContent !== '') {
            // If there is content and no 'dataTables_empty' class, enable the Save button
            saveButton.disabled = false;
        } else {
            // If the 'dataTables_empty' class is present or there is no content, disable the Save button
            saveButton.disabled = true;
        }
    }

    updateSaveButtonStatus();

    var selectedPackageIds = [];

    // Delete product
    var deleteProduct = function () {
        KTUtil.on(table, '[data-kt-action="product_remove"]', 'click', function (e) {
            e.preventDefault();

            // Select parent row
            const parent = e.target.closest('tr');

            // Get customer name
            const productName = parent.querySelectorAll('td')[0].innerText;

            const packageIdInput = parent.querySelector('input[name="package_id"]');
            const packageId = packageIdInput ? packageIdInput.value : null;

            // SweetAlert2 pop up --- official docs reference: https://sweetalert2.github.io/
            Swal.fire({
                text: "Are you sure you want to delete " + productName + "?",
                icon: "warning",
                showCancelButton: true,
                buttonsStyling: false,
                confirmButtonText: "Yes, delete!",
                cancelButtonText: "No, cancel",
                customClass: {
                    confirmButton: "btn fw-bold btn-danger",
                    cancelButton: "btn fw-bold btn-active-light-primary"
                }
            }).then(function (result) {
                if (result.value) {
                    Swal.fire({
                        text: "You have deleted " + productName + "!.",
                        icon: "success",
                        buttonsStyling: false,
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn fw-bold btn-primary",
                        }
                    }).then(function () {
                        // Remove current row
                        datatable.row($(parent)).remove().draw();

                        selectedPackageIds = selectedPackageIds.filter(id => id !== packageId);
                        updateSaveButtonStatus();
                    });
                } else if (result.dismiss === 'cancel') {
                    Swal.fire({
                        text: productName + " was not deleted.",
                        icon: "error",
                        buttonsStyling: false,
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn fw-bold btn-primary",
                        }
                    });
                }
            });
        });

    }

    // Modal handlers
    var addProduct = function () {
        // Select modal buttons
        const closeButton = modalEl.querySelector('#kt_modal_add_product_close');
        const cancelButton = modalEl.querySelector('#kt_modal_add_product_cancel');
        const submitButton = modalEl.querySelector('#kt_modal_add_product_submit');

        // Cancel button action
        cancelButton.addEventListener('click', function (e) {
            e.preventDefault();

            Swal.fire({
                text: "Are you sure you would like to cancel?",
                icon: "warning",
                showCancelButton: true,
                buttonsStyling: false,
                confirmButtonText: "Yes, cancel it!",
                cancelButtonText: "No, return",
                customClass: {
                    confirmButton: "btn btn-primary",
                    cancelButton: "btn btn-active-light"
                }
            }).then(function (result) {
                if (result.value) {
                    modal.hide(); // Hide modal
                } else if (result.dismiss === 'cancel') {
                    Swal.fire({
                        text: "Your form has not been cancelled!.",
                        icon: "error",
                        buttonsStyling: false,
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn btn-primary",
                        }
                    });
                }
            });
        });

        submitButton.addEventListener('click', function (e) {
            e.preventDefault();

            // Check all radio buttons
            var radio = modalEl.querySelector('input[type="radio"]:checked');

            // Define datatable row node
            var rowNode;

            if (radio && radio.checked === true) {

                // Get the package ID
                var packageId = radio.getAttribute('data-kt-package-id');
                var price = radio.getAttribute('data-kt-product-price');
                var priceWithSymbol = radio.getAttribute('data-kt-product-price-symbol');
                var productName = radio.getAttribute('data-kt-product-name');
                // var packageSize = radio.getAttribute('data-kt-package-size');
                var packageType = radio.getAttribute('data-kt-package-type');
                var packageVolumeSize = radio.getAttribute('data-kt-package-volume-type');
                var productImage = radio.getAttribute('data-kt-product-image');
                var customerDeliveryType = radio.getAttribute('data-kt-customer-delivery-type');
                var productType = radio.getAttribute('data-kt-product-type');
                var productUsage = radio.getAttribute('data-kt-product-usage');


                // Check if the package ID is already selected
                if (selectedPackageIds.includes(packageId)) {
                    alert('This package is already selected.');
                    return;
                }
    
                function getPackageTypeBadge(packageType) {
                    const badges = {
                        'morning': '<span class="badge badge-light-info me-1 mb-1 border border-secondary">Morning</span>',
                        'evening': '<span class="badge badge-light-warning me-1 mb-1 border border-secondary">Evening</span>',
                        'both': '<span class="badge badge-light-primary me-1 mb-1 border border-secondary">Both</span>',
                    };

                    return badges[packageType] || '<span class="badge badge-light-default me-1 mb-1 border border-secondary">Unknown</span>';
                }

                var packageTypeBadgeHTML = getPackageTypeBadge(packageType);

                // Create a new div element for the start date input
                var packageIdDiv = document.createElement('div');
                packageIdDiv.className = 'form-group min-w-150px';

                var sampleBadge = productType === 'sample'
    ? '<span class="badge badge-light-primary me-1 mb-1 border border-secondary">Sample</span>'
                    : '';
                
                    var subUsages = productType === 'sample'
                    ? `<span class="me-1 mb-1 border border-secondary">It's applicable start date to ${productUsage} days</span>`
                    : '';
                
                    packageIdDiv.innerHTML = `
                    <label class="mb-2 fs-7" for="package_id">Product Name</label>
                    <input class="form-control" name="package_id" type="hidden" value="${packageId}" data-product-type="${productType}" data-product-usage="${productUsage}">
                    <div class="d-flex align-items-start">
                        <div class="symbol symbol-50px me-3 border">
                            <img src="${productImage}" alt="" width="50" height="50">
                        </div>
                        <div>
                            <div class="fs-6 text-gray-800 fw-bold">${productName} - ${priceWithSymbol}</div>
                            <div class="mt-1">
                                ${packageTypeBadgeHTML}
                                ${sampleBadge}
                            </div>
                            ${subUsages}
                        </div>
                    </div>
                `;
                

                // Add the package ID to the array
                selectedPackageIds.push(packageId);

                // Create a new div element for the start date input
                var startDateDiv = document.createElement('div');
                startDateDiv.className = 'form-group w-150px';

                startDateDiv.innerHTML = `
                        <label class="mb-2 fs-7" for="start_date">Start Date</label>
                        <input class="form-control flatpickr" name="start_date" type="text" placeholder="Select start date...">
                `;

                // Create a new div element for the end date input
                var endDateDiv = document.createElement('div');
                endDateDiv.className = 'form-group w-150px';

                endDateDiv.innerHTML = `
                        <label class="mb-2 fs-7" for="end_date">End Date</label>
                        <input class="form-control flatpickr" name="end_date" type="text" placeholder="Select end date..." data-min-date="${radio.getAttribute('data-kt-start-date') || 'today'}">
                `;

                // Create a new div element for the delivery_type dropdown
                var deliveryTypeDiv = document.createElement('div');
                deliveryTypeDiv.className = 'form-group w-150px';
                if (productType === 'sample') {
                    endDateDiv.style.display = 'none';
                }

                if (customerDeliveryType == 'morning') {

                    deliveryTypeDiv.innerHTML = `
                        <label class="mb-2 fs-7" for="delivery_type">Delivery Type</label>
                        <select class="form-control wc-resp-dropdown" id="delivery_type" name="delivery_type">
                            <option value="morning">Morning</option>
                        </select>
                    `;
                } else if (customerDeliveryType == 'evening') {
                    deliveryTypeDiv.innerHTML = `
                        <label class="mb-2 fs-7" for="delivery_type">Delivery Type</label>
                        <select class="form-control wc-resp-dropdown" id="delivery_type" name="delivery_type">
                            <option value="evening" >Evening</option>
                        </select>
                    `;
                } else {
                    if (packageType == 'morning') {

                        deliveryTypeDiv.innerHTML = `
                            <label class="mb-2 fs-7" for="delivery_type">Delivery Type</label>
                            <select class="form-control wc-resp-dropdown" id="delivery_type" name="delivery_type">
                                <option value="morning">Morning</option>
                                <option value="evening" disabled>Evening</option>
                                <option value="both" disabled>Both</option>
                            </select>
                        `;
                    } else if (packageType == 'evening') {
                        deliveryTypeDiv.innerHTML = `
                            <label class="mb-2 fs-7" for="delivery_type">Delivery Type</label>
                            <select class="form-control wc-resp-dropdown" id="delivery_type" name="delivery_type">
                                <option value="morning" disabled>Morning</option>
                                <option value="evening">Evening</option>
                                <option value="both" disabled>Both</option>
                            </select>
                        `;
                    } else {

                        deliveryTypeDiv.innerHTML = `
                        <label class="mb-2 fs-7" for="delivery_type">Delivery Type</label>
                        <select class="form-control wc-resp-dropdown" id="delivery_type" name="delivery_type">
                            <option value="morning">Morning</option>
                            <option value="evening">Evening</option>
                            <option value="both">Both</option>
                        </select>
                    `;
                    }

                }

                // Create a new div element for the frequency type dropdown
                var frequencyTypeDiv = document.createElement('div');
                frequencyTypeDiv.className = 'form-group w-150px';

                frequencyTypeDiv.innerHTML = `
                        <label class="mb-2 fs-7" for="frequency_type">Frequency Type</label>
                        <select class="form-control wc-resp-dropdown" id="frequency_type" name="frequency_type">
                            <option value="every_day" selected>Every Day</option>
                            <option value="alternate_day">Alternate Day</option>
                            <option value="every_3_day">Every 3 Day</option>
                            <option value="day_wise">Day Wise</option>
                        </select>
                `;

           
                // Create a new div element for the frequency value input
                var frequencyValueDiv = document.createElement('div');
                frequencyValueDiv.className = 'form-group w-150px';
                frequencyValueDiv.style.display = 'none';
                frequencyValueDiv.setAttribute('name', 'frequencyValueDiv');

                frequencyValueDiv.innerHTML = `
                        <label class="mb-2 fs-7" for="frequency_value">Frequency Value</label>
                        <input class="form-control" name="frequency_value" type="number" id="frequency_value" value="" placeholder="Enter frequency value here...">
                `;

                // Create a new div element for the qty input
                var qtyDiv = document.createElement('div');
                qtyDiv.className = 'form-group w-100px';
                qtyDiv.style.display = 'block';
                qtyDiv.setAttribute('name', 'qtyDiv');

                qtyDiv.innerHTML = `
                        <label class="mb-2 fs-7" for="qty">Qty</label>
                        <input class="form-control" name="qty" pattern="[0-9]*" type="number" id="qty" min="1" placeholder="1" onkeydown="convertToPositive(this)" value="1">
                `;
             // Hide end date and frequency type for sample products
                if (productType === 'sample') {
                    endDateDiv.style.display = 'none';
                    frequencyTypeDiv.style.display = 'none';
                    qtyDiv.style.display = 'none';

                }

                // Create a new div element for the schedule input and day-wise quantity
                var scheduleDiv = document.createElement('div');
                scheduleDiv.className = 'form-group min-w-200px';
                scheduleDiv.style.display = 'none';
                scheduleDiv.setAttribute('name', 'scheduleDiv');

                scheduleDiv.innerHTML = `
                        <div class="row">
                            <div class="col-md-1">
                                <input class="form-control" name="schedule" type="text" id="schedule" value="${JSON.stringify(generateDaysString())}" placeholder="Enter schedule here..." style="display: none;">
                            </div>
                            <div class="col-md-11">
                            <div class="days-subs">
                            ${generateDayWiseInputs()}
                            </div>
                            </div>
                        </div>
                `;

                // Function to generate day-wise inputs
                function generateDayWiseInputs() {
                    var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                    var inputs = '';

                    days.forEach(function (day, index) {
                        inputs += `
                                <div class="form-floating mb-4">
                                    <input type="number" pattern="[0-9]*" class="form-control" name="day_wise_quantity" min="0" id="day_wise_quantity_${index}" onkeydown="convertToPositive(this)" placeholder="name@example.com"/>
                                    <label class="mb-2 fs-7" for="day_wise_quantity_${index}">${day}</label>
                                </div>
                        `;
                    });

                    return inputs;
                }

                // Function to generate a string containing all days
                function generateDaysString() {
                    var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                    return days;
                }

                // Add the generated HTML to the DataTable row
                rowNode = datatable.row.add([
                    packageIdDiv.outerHTML,
                    deliveryTypeDiv.outerHTML,
                    frequencyTypeDiv.outerHTML,
                    startDateDiv.outerHTML,
                    endDateDiv.outerHTML,
                    qtyDiv.outerHTML,
                    frequencyValueDiv.outerHTML,
                    scheduleDiv.outerHTML,
                    '<td class="text-start"><a href="#" class="btn btn-icon btn-flex btn-active-light-primary w-30px h-30px me-3" data-bs-toggle="tooltip" title="Delete" data-kt-action="product_remove"><i class="ki-outline ki-trash fs-3"></i></a></td>'
                ]).draw().node();

                // Add custom class to last column
                $(rowNode).find('td').eq(9).addClass('text-end');
                // $('.wc-resp-dropdown').select2();

                // Update input values for schedule and day_wise_quantity
                var scheduleInput = rowNode.querySelector('[name="schedule"]');
                var dayWiseQuantityInputs = rowNode.querySelectorAll('[name="day_wise_quantity"]');

                scheduleInput.value = JSON.stringify(generateDaysString());
                dayWiseQuantityInputs.forEach(function (input, index) {
                    input.value = 0;
                });

                var today = new Date();

                // Format today's date in 'd-m-Y' format
                var todayFormatted = today.getDate() + '-' + (today.getMonth() + 1) + '-' + today.getFullYear();

                var tomorrow = new Date(today);
                tomorrow.setDate(today.getDate() + 1);

                // Format tomorrow's date in 'd-m-Y' format
                var tomorrowFormatted = tomorrow.getDate() + '-' + (tomorrow.getMonth() + 1) + '-' + tomorrow.getFullYear();

                // Initialize flatpickr for start_date input
                var startPicker = flatpickr(rowNode.querySelector('[name="start_date"]'), {
                    defaultDate: todayFormatted,
                    minDate: today,
                    dateFormat: 'd-m-Y',
                    onChange: function (selectedDates, dateStr) {
                        // When start_date is selected, update minDate for end_date input
                        if (dateStr !== '') {
                            endPicker.set('minDate', dateStr);
                        }
                    }
                });

                // Initialize flatpickr for end_date input
                var endPicker = flatpickr(rowNode.querySelector('[name="end_date"]'), {
                    minDate: tomorrowFormatted,
                    dateFormat: 'd-m-Y'
                });


                var deliveryTypeDropdown = rowNode.querySelector('#delivery_type');
                deliveryTypeDropdown.addEventListener('change', function () {
                    showHideFields(this.value, rowNode);
                });
                // Add event listener for the frequency type dropdown
                var frequencyTypeDropdown = rowNode.querySelector('#frequency_type');
                frequencyTypeDropdown.addEventListener('change', function () {
                    showHideFields(this.value, rowNode);
                });
                updateSaveButtonStatus();
            }

            modal.hide(); // Remove modal
        });

        // Function to show/hide fields based on the selected frequency type
        function showHideFields(frequencyType, rowNode) {
            var frequencyValueDiv = rowNode.querySelector('.form-group[name="frequencyValueDiv"]');
            var qtyDiv = rowNode.querySelector('.form-group[name="qtyDiv"]');
            var scheduleDiv = rowNode.querySelector('.form-group[name="scheduleDiv"]');
            var startDateDiv = rowNode.querySelector('[name="start_date"]').closest('.form-group');
            var endDateDiv = rowNode.querySelector('[name="end_date"]').closest('.form-group');

            if (frequencyType === 'every_day') {
                frequencyValueDiv.style.display = 'none';
                qtyDiv.style.display = 'block';
                scheduleDiv.style.display = 'none';
                // If "One time" is selected, disable start_date and end_date inputs
                startDateDiv.style.display = 'block';
                endDateDiv.style.display = 'block';



                // Change the label from "Start Date" to "Date"
                rowNode.querySelector('[for="start_date"]').innerText = 'Start Date';
                rowNode.querySelector('[name="frequency_value"]').value = '';
            } else if (frequencyType === 'day_wise') {
                rowNode.querySelector('[name="qty"]').value = '';
                frequencyValueDiv.style.display = 'none';
                qtyDiv.style.display = 'none';
                scheduleDiv.style.display = 'block';
                // If "One time" is selected, disable start_date and end_date inputs
                startDateDiv.style.display = 'block';
                endDateDiv.style.display = 'block';



                // Change the label from "Start Date" to "Date"
                rowNode.querySelector('[for="start_date"]').innerText = 'Start Date';
                rowNode.querySelector('[name="frequency_value"]').value = '';
            } else if (frequencyType === 'alternate_day') {
                rowNode.querySelector('[name="frequency_value"]').value = '2';
                frequencyValueDiv.style.display = 'none';
                qtyDiv.style.display = 'block';
                scheduleDiv.style.display = 'none';
                // If "One time" is selected, disable start_date and end_date inputs
                startDateDiv.style.display = 'block';
                endDateDiv.style.display = 'block';


                // Change the label from "Start Date" to "Date"
                rowNode.querySelector('[for="start_date"]').innerText = 'Start Date';

            } else if (frequencyType === 'every_3_day') {
                rowNode.querySelector('[name="frequency_value"]').value = '3';
                frequencyValueDiv.style.display = 'none';
                qtyDiv.style.display = 'block';
                scheduleDiv.style.display = 'none';
                // If "One time" is selected, disable start_date and end_date inputs
                startDateDiv.style.display = 'block';
                endDateDiv.style.display = 'block';

                // Change the label from "Start Date" to "Date"
                rowNode.querySelector('[for="start_date"]').innerText = 'Start Date';

            } else if (frequencyType === 'nth_day') {
                frequencyValueDiv.style.display = 'block';
                qtyDiv.style.display = 'block';
                scheduleDiv.style.display = 'none';
                // If "One time" is selected, disable start_date and end_date inputs
                startDateDiv.style.display = 'block';
                endDateDiv.style.display = 'block';

                // Change the label from "Start Date" to "Date"
                rowNode.querySelector('[for="start_date"]').innerText = 'Start Date';
                rowNode.querySelector('[name="frequency_value"]').value = '';
            } else if (frequencyType === 'one_time') {
                frequencyValueDiv.style.display = 'none';
                qtyDiv.style.display = 'block';
                scheduleDiv.style.display = 'none';

                // If "One time" is selected, disable start_date and end_date inputs
                startDateDiv.style.display = 'block';
                endDateDiv.style.display = 'none';

                // Set the same date for both start_date and end_date
                var dateInput = rowNode.querySelector('[name="start_date"]');
                var selectedDate = dateInput.value;

                // Change the label from "Start Date" to "Date"
                rowNode.querySelector('[for="start_date"]').innerText = 'Date';
                rowNode.querySelector('[name="frequency_value"]').value = '';
            }
        }
    }



    return {
        init: function () {
            modalEl = document.getElementById('kt_modal_add_product');

            // Select modal -- more info on Bootstrap modal: https://getbootstrap.com/docs/5.0/components/modal/
            modal = new bootstrap.Modal(modalEl);

            table = document.querySelector('#kt_subscription_products_table');

            initDatatable();
            deleteProduct();
            addProduct();
            showHideFields();
        }
    }
}();

// On document ready
KTUtil.onDOMContentLoaded(function () {
    KTSubscriptionsProducts.init();
});
