"use strict";

// Class definition
var KTAppEcommerceSalesSaveOrder = function () {
    // Shared variables
    var table;
    var datatable;

    var form;

    // Private functions
    const initSaveOrder = () => {
        // Init flatpickr
        var today = new Date();
        $('#kt_ecommerce_edit_order_date').flatpickr({
            altInput: true,
            altFormat: "d F, Y",
            dateFormat: "Y-m-d",
            defaultDate: today
        });

        // Init datatable --- more info on datatables: https://datatables.net/manual/
        table = document.querySelector('#kt_ecommerce_edit_order_product_table');
        datatable = $(table).DataTable({
            'order': [],
            "scrollY": "400px",
            "scrollCollapse": true,
            "paging": false,
            "info": false,
            'columnDefs': [{
                    orderable: false,
                    targets: 0
                }, // Disable ordering on column 0 (checkbox)
            ]
        });
    }


    // Private functions
    var updateTotal = function () {
        var items = [].slice.call(document.querySelectorAll('[data-kt-element="items"] [data-kt-element="item"]'));
        var grandTotalNumeric = 0; // Use a distinct name for the numeric sum
    
        var wNumbFormatter = wNumb({ // Use a distinct name for the formatter instance
            //prefix: '$ ',
            decimals: 2,
            thousand: ','
        });
    
        items.map(function (item) {
            var quantityInput = item.querySelector('[data-kt-element="qty"]'); // This is an <input>
            var priceInput = item.querySelector('[data-kt-element="price"]');   // This is an <input name="price[]">
    
            // 1. Get the current value from the price input.
            //    It might have been set by handleProductSelect (hopefully clean) or by a previous run of updateTotal.
            //    Use wNumbFormatter.from() to parse it robustly, in case it somehow got commas.
            var priceNumeric = wNumbFormatter.from(priceInput.value);
            priceNumeric = (!priceNumeric || priceNumeric < 0) ? 0 : priceNumeric;
    
            var quantityNumeric = parseInt(quantityInput.value);
            quantityNumeric = (!quantityNumeric || quantityNumeric < 0) ? 1 : quantityNumeric;
    
            // 2. Set the VALUE of the price INPUT (for submission) to the CLEAN NUMERIC value.
            //    If the input is readonly and you want its visible text to be formatted,
            //    this means the visible text in that input will be "2600.00", not "2,600.00".
            //    This is necessary if this input's value is what gets submitted.
            priceInput.value = priceNumeric; // Example: 2600.00 (as a string, but no comma)
            quantityInput.value = quantityNumeric; // Example: 1
    
            // 3. Update the DISPLAY element for the item's total using the formatted string.
            item.querySelector('[data-kt-element="total"]').innerText = wNumbFormatter.to(priceNumeric * quantityNumeric);
    
            // 4. Add to the numeric grand total.
            grandTotalNumeric += priceNumeric * quantityNumeric;
        });
    
        // 5. Update DISPLAY elements for sub-total and grand-total.
        if (form.querySelector('[data-kt-element="sub-total"]')) {
            form.querySelector('[data-kt-element="sub-total"]').innerText = wNumbFormatter.to(grandTotalNumeric);
        }
        if (form.querySelector('[data-kt-element="grand-total"]')) {
            form.querySelector('[data-kt-element="grand-total"]').innerText = wNumbFormatter.to(grandTotalNumeric);
        }
    
        // 6. Set the VALUE of the order_amount INPUT (for submission) to the CLEAN NUMERIC grandTotal.
        var orderAmountInput = document.querySelector('input[name="order_amount"]');
        if (orderAmountInput) {
            orderAmountInput.value = grandTotalNumeric; // Example: 2600.00 (as a string from number, no comma)
        }
    };

    var handleEmptyState = function () {
        if (form.querySelectorAll('[data-kt-element="items"] [data-kt-element="item"]').length === 0) {
            var item = form.querySelector('[data-kt-element="empty-template"] tr').cloneNode(true);
            form.querySelector('[data-kt-element="items"] tbody').appendChild(item);
        } else {
            KTUtil.remove(form.querySelector('[data-kt-element="items"] [data-kt-element="empty"]'));
        }
    }

    var handleForm = function (element) {

        // Remove item
        KTUtil.on(form, '[data-kt-element="items"] [data-kt-element="remove-item"]', 'click', function (e) {
            e.preventDefault();

            const removedItem = this.closest('[data-kt-element="item"]');
            const itemId = removedItem.getAttribute('data-kt-ecommerce-edit-order-id');

            // Remove the item
            KTUtil.remove(removedItem);

            // Uncheck the corresponding checkbox
            const checkbox = document.querySelector('[data-kt-ecommerce-checkbox-id="checkbox_' + itemId + '"]');
            if (checkbox) {
                checkbox.checked = false;
            }

            const tableBody = document.querySelector('table[data-kt-element="items"] tbody');
            const itemsCount = tableBody.querySelectorAll('[data-kt-element="item"]').length;

            const orderDate = document.getElementById('kt_ecommerce_edit_order_date').value;
            // Enable or disable the "Save" button based on the items count
            const saveButton = document.querySelector('[data-kt-element="save-button"]');
            saveButton.disabled = itemsCount === 0 || orderDate == '';

            handleEmptyState();
            updateTotal();
        });

        // Handle price and quantity changes
        KTUtil.on(form, '[data-kt-element="items"] [data-kt-element="qty"], [data-kt-element="items"] [data-kt-element="price"]', 'change', function (e) {
            e.preventDefault();

            updateTotal();
        });
    }

    var initForm = function (element) {
        // Due date. For more info, please visit the official plugin site: https://flatpickr.js.org/
        var invoiceDate = $(form.querySelector('[name="invoice_date"]'));
        invoiceDate.flatpickr({
            enableTime: false,
            dateFormat: "d, M Y",
        });

        // Due date. For more info, please visit the official plugin site: https://flatpickr.js.org/
        var dueDate = $(form.querySelector('[name="invoice_due_date"]'));
        dueDate.flatpickr({
            enableTime: false,
            dateFormat: "d, M Y",
        });
    }

    // Search Datatable --- official docs reference: https://datatables.net/reference/api/search()
    // var handleSearchDatatable = () => {
    //     const filterSearch = document.querySelector('[data-kt-ecommerce-edit-order-filter="search"]');
    //     filterSearch.addEventListener('keyup', function (e) {
    //         datatable.search(e.target.value).draw();
    //     });
    // }

    // Trigger updateTotal after adding or removing products
    const triggerUpdateTotal = () => {
        updateTotal();
    };

    // Handle product select
    const handleProductSelect = () => {
        // Define variables
        const deliveryTypeDropdown = document.querySelector('#deliveryTypeFilter').value;
        const checkboxes = document.querySelectorAll('#kt_ecommerce_edit_order_product_table [type="checkbox"]');
        const tableBody = document.querySelector('table[data-kt-element="items"] tbody');
        const itemTemplate = document.querySelector('[data-kt-element="item-template"] tr').cloneNode(true);
        const emptyTemplate = document.querySelector('[data-kt-element="empty-template"] tr').cloneNode(true);

        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function () {
                const parentRow = checkbox.closest('tr');
                const productId = parentRow.querySelector('[data-kt-ecommerce-edit-order-id]').getAttribute('data-kt-ecommerce-edit-order-id');
                const selectedProduct = tableBody.querySelector('[data-kt-ecommerce-edit-order-id="' + productId + '"]');

                if (checkbox.checked) {
                    // Add product to the table
                    const newRow = itemTemplate.cloneNode(true);
                    const productName = parentRow.querySelector('.fw-bold').innerText.trim();
                    const productPrice = parentRow.querySelector('[data-kt-ecommerce-edit-order-filter="price"]').innerText.trim();
                    const productImage = parentRow.querySelector('.symbol-label').getAttribute('style');
                    // const selectedPackageType = document.querySelector('#product-package-' + productId);
                    // let selectedPackageTypeVal = 'both';
                    // if (selectedPackageType.value == 'both' || selectedPackageType.value == 'morning') {
                    //     selectedPackageTypeVal = 'morning';
                    // } else if (selectedPackageType.value == 'both' || selectedPackageType.value == 'evening') {
                    //     selectedPackageTypeVal = 'evening';
                    // }

                    newRow.querySelector('[data-kt-element="package_id"]').setAttribute('name', `package_id[]`);
                    newRow.querySelector('[data-kt-element="name"]').setAttribute('name', `name[]`);
                    newRow.querySelector('[data-kt-element="price"]').setAttribute('name', `price[]`);
                    newRow.querySelector('[data-kt-element="qty"]').setAttribute('name', `qty[]`);
                    // newRow.querySelector('[data-kt-element="delivery_type"]').setAttribute('name', `delivery_type[]`);
                    newRow.querySelector('[data-kt-element="package_id"]').value = productId;
                    newRow.querySelector('[data-kt-element="name"]').value = productName;
                    newRow.querySelector('[data-kt-element="price"]').value = productPrice;
                    // newRow.querySelector('[data-kt-element="delivery_type"]').value = selectedPackageTypeVal;
                    newRow.querySelector('.symbol-label').setAttribute('style', productImage);
                    newRow.setAttribute('data-kt-ecommerce-edit-order-id', productId);

                    tableBody.appendChild(newRow);
                } else {
                    // Remove product from the table
                    if (selectedProduct) {
                        tableBody.removeChild(selectedProduct);
                    }
                }

                // Check if there are any items in the table
                const itemsCount = tableBody.querySelectorAll('[data-kt-element="item"]').length;

                const orderDate = document.getElementById('kt_ecommerce_edit_order_date').value;

                // Enable or disable the "Save" button based on the items count
                const saveButton = document.querySelector('[data-kt-element="save-button"]');
                saveButton.disabled = itemsCount === 0 || orderDate == '';

                handleEmptyState();
                triggerUpdateTotal();
            });
        });

    }

    const initOrderProcess = () => {

        const morningTab = document.querySelector('[ data-kt-tab="only_morning_type"]');
        const eveningTab = document.querySelector('[ data-kt-tab="only_evening_type"]');

        morningTab.addEventListener('click', function (e) {
            const tableBody = document.querySelector('table[data-kt-element="items"] tbody');
            tableBody.innerHTML = '';

            const checkboxes = document.querySelectorAll('[data-kt-ecommerce-checkbox-id]');

            checkboxes.forEach((item, index) => {
                item.checked = false;
            });
            handleEmptyState();

            const delivery_time_dropdown = document.querySelector('[name="delivery_time"]');

            delivery_time_dropdown.value = 'morning';

            const event = new Event('change');
            delivery_time_dropdown.dispatchEvent(event);

        });

        eveningTab.addEventListener('click', function (e) {
            const tableBody = document.querySelector('table[data-kt-element="items"] tbody');
            tableBody.innerHTML = '';

            const checkboxes = document.querySelectorAll('[data-kt-ecommerce-checkbox-id]');

            checkboxes.forEach((item, index) => {
                item.checked = false;
            });
            handleEmptyState();

            const delivery_time_dropdown = document.querySelector('[name="delivery_time"]');

            delivery_time_dropdown.value = 'evening';

            const event = new Event('change');
            delivery_time_dropdown.dispatchEvent(event);
        });
    }

    // Public methods
    return {
        init: function () {

            initSaveOrder();
            // handleSearchDatatable();
            handleProductSelect();

            form = document.querySelector('#kt_invoice_form');

            handleForm();
            initForm();
            updateTotal();
            initOrderProcess();
        }
    };
}();

// On document ready
KTUtil.onDOMContentLoaded(function () {
    KTAppEcommerceSalesSaveOrder.init();
});
